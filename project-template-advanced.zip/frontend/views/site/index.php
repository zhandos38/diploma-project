<?php

$this->title = 'Главная страница';
?>
<h1>Hello world</h1>